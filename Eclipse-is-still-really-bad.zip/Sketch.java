import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    // size of the image
    size(800,800);
  }

  public void setup() {
    // background colour
    background(84,175,255);
}

  public void draw() {
    // stem
    fill(53,136,86);
    rect(390,400,16,400); 
    // upper leaf
    fill(53,136,86);
    ellipse(448,600,80,20); 
    // lower leaf
    fill(53,136,86);
    ellipse(348,650,80,20); 
    


    // flower center
    fill(255,242,0);
    ellipse(400,400,100,100);
    // left petal
    fill(255,0,0);
    ellipse(300,400,100,100);
    // right petal
    fill(255,0,0);
    ellipse(500,400,100,100);
    // upper right petal
    fill(255,0,0);
    ellipse(450,312,100,100);
    // upper left petal
    fill(255,0,0);
    ellipse(350,312,100,100);
    // lower right petal
    fill(255,0,0);
    ellipse(450,488,100,100);
    // lower left petal
    fill(255,0,0);
    ellipse(350,488,100,100);
  }
}