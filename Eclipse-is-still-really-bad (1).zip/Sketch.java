import processing.core.PApplet;

public class Sketch extends PApplet {

  public void settings() {
    // size of the image
    size(400*2, 400*2);
  }

  public void setup() {
    // background colour
    background(84,175,255);
}

  public void draw() {
    // stem
    fill(53,136,86);
    rect(195*2,200*2,8*2,200*2); 
    // upper leaf
    fill(53,136,86);
    ellipse(244*2,300*2,40*2,10*2); 
    // lower leaf
    fill(53,136,86);
    ellipse(174*2,975*2,40*2,10*2); 

    // flower center
    fill(255,242,0);
    ellipse(200*2,200*2,50*2,50*2);
    // left petal
    fill(255,0,0);
    ellipse(150*2,200*2,50*2,50*2);
    // right petal
    fill(255,0,0);
    ellipse(250*2,200*2,50*2,50*2);
    // upper right petal
    fill(255,0,0);
    ellipse(225*2,155*2,50*2,50*2);
    // upper left petal
    fill(255,0,0);
    ellipse(175*2,155*2,50*2,50*2);
    // lower right petal
    fill(255,0,0);
    ellipse(225*2,245*2,50*2,50*2);
    // lower left petal
    fill(255,0,0);
    ellipse(175*2,245*2,50*2,50*2);
  }
}